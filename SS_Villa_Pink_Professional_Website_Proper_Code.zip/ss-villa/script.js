const btn=document.querySelector('.menu-btn');
const nav=document.querySelector('.nav-links');
if(btn)btn.addEventListener('click',()=>nav.classList.toggle('show'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('show')));
const form=document.querySelector('#bookingForm');
if(form) {
    form.addEventListener('submit',e=> {
        e.preventDefault();
        alert('Thank you! Your booking enquiry has been received.');
        form.reset();
    }
    );
}
